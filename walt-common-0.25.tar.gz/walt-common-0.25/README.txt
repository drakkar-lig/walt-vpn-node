This package provides common python modules for various WalT components.
See https://github.com/drakkar-lig/walt-python-packages for more info.
