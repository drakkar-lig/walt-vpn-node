This package provides components of related to WalT VPN.
See https://github.com/drakkar-lig/walt-python-packages for more info.
