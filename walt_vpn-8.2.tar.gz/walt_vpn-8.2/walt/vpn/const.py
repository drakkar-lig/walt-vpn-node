VPN_SOCK_PATH = "/var/run/walt-vpn.sock"
